/*
 * College Lab Resource Controller - Counting Semaphore
 * Compile: gcc main.c -o lab_controller -pthread
 * Run:     ./lab_controller
 */

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

#define TOTAL_COMPUTERS 3
#define TOTAL_STUDENTS  6

sem_t computer_sem;              // Counting semaphore
pthread_mutex_t display_mutex;   // Protects shared counters and display
int available_computers = TOTAL_COMPUTERS;
int allocated_computers = 0;

void *student_process(void *arg)
{
    int student_id = *(int *)arg;

    printf("Student %d is requesting a computer...\\n", student_id);

    /* Wait until a computer becomes available. */
    sem_wait(&computer_sem);

    pthread_mutex_lock(&display_mutex);
    available_computers--;
    allocated_computers++;

    printf("\\nStudent %d allocated a computer.\\n", student_id);
    printf("Allocated computers: %d\\n", allocated_computers);
    printf("Available computers: %d\\n\\n", available_computers);
    pthread_mutex_unlock(&display_mutex);

    /* Simulate the student using the computer. */
    printf("Student %d is working in the laboratory...\\n", student_id);
    sleep(2);

    /* Release the computer after completing the work. */
    pthread_mutex_lock(&display_mutex);
    allocated_computers--;
    available_computers++;

    printf("\\nStudent %d completed the work and released the computer.\\n",
           student_id);
    printf("Allocated computers: %d\\n", allocated_computers);
    printf("Available computers: %d\\n\\n", available_computers);
    pthread_mutex_unlock(&display_mutex);

    sem_post(&computer_sem);
    return NULL;
}

int main(void)
{
    pthread_t students[TOTAL_STUDENTS];
    int student_ids[TOTAL_STUDENTS];

    if (sem_init(&computer_sem, 0, TOTAL_COMPUTERS) != 0) {
        perror("Semaphore initialization failed");
        return EXIT_FAILURE;
    }

    if (pthread_mutex_init(&display_mutex, NULL) != 0) {
        perror("Mutex initialization failed");
        sem_destroy(&computer_sem);
        return EXIT_FAILURE;
    }

    printf("===== COLLEGE LAB RESOURCE CONTROLLER =====\\n");
    printf("Total computers: %d\\n", TOTAL_COMPUTERS);
    printf("Available computers: %d\\n\\n", available_computers);

    for (int i = 0; i < TOTAL_STUDENTS; i++) {
        student_ids[i] = i + 1;
        if (pthread_create(&students[i], NULL, student_process,
                           &student_ids[i]) != 0) {
            perror("Thread creation failed");
            return EXIT_FAILURE;
        }
    }

    for (int i = 0; i < TOTAL_STUDENTS; i++) {
        pthread_join(students[i], NULL);
    }

    printf("===== LABORATORY STATUS =====\\n");
    printf("Allocated computers: %d\\n", allocated_computers);
    printf("Available computers: %d\\n", available_computers);
    printf("All students have completed their work.\\n");

    pthread_mutex_destroy(&display_mutex);
    sem_destroy(&computer_sem);

    return EXIT_SUCCESS;
}
