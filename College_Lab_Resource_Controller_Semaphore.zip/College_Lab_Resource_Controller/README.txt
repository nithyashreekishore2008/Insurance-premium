COLLEGE LAB RESOURCE CONTROLLER - COUNTING SEMAPHORE

Files:
- main.c       C program using a POSIX counting semaphore and pthreads
- Makefile     Build instructions

What the program does:
1. Creates a counting semaphore with a value of 3 (three computers).
2. Starts 6 student threads.
3. A student calls sem_wait() to obtain a computer.
4. If no computer is available, the student waits until another student releases one.
5. After completing the simulated work, the student calls sem_post() to release the computer.
6. Displays allocated and available computer counts.

Requirements:
- GCC compiler
- POSIX environment such as Linux, Ubuntu, or WSL on Windows

Compile:
    gcc main.c -o lab_controller -pthread

Run:
    ./lab_controller

You can change TOTAL_COMPUTERS and TOTAL_STUDENTS at the top of main.c.

Note:
The order of student messages may differ each time because threads execute concurrently.
